wait(0.5); if _G.AutoArrest == false or game.PlaceId ~= 2788229376 then return else repeat wait() until game.Players.LocalPlayer end

wait(15)
for i, v in next, game.Workspace:GetDescendants() do
	if v:IsA("Seat") then
		v:Destroy()
	end
end
local Plr = game.Players.LocalPlayer

function serverhop()
    print("PENIS")
	Plr:Destroy()
	local x = {}
	for _, v in ipairs(game:GetService("HttpService"):JSONDecode(game:HttpGetAsync("https://games.roblox.com/v1/games/" .. game.PlaceId .. "/servers/Public?sortOrder=Asc&limit=100")).data) do
		if type(v) == "table" and v.maxPlayers > v.playing and v.id ~= game.JobId then
			x[#x + 1] = v.id
		end
	end
	if #x > 0 then
		game:GetService("TeleportService"):TeleportToPlaceInstance(game.PlaceId, x[math.random(1, #x)])
	end
end

spawn(function()
    wait(300)
    serverhop()
end)

game:GetService("RunService").Stepped:connect(function()
    Plr.Character.Humanoid:ChangeState(11)
end)
Plr.CharacterAdded:Connect(function(character)
    repeat wait() until character:FindFirstChild("FULLY_LOADED_CHAR")
    e(character)
end)
function e(character)
    for i, v in pairs(game.Workspace.Ignored.ItemsDrop:GetChildren()) do
        if v:FindFirstChild("[Knife]") and Plr.Character:FindFirstChild("[Knife]") == nil and Plr.Backpack:FindFirstChild("[Knife]") == nil then
            Plr.Character.HumanoidRootPart.CFrame = v.CFrame
            wait(1)
        end
    end
    for i, v in pairs(character:GetChildren()) do
        if v:FindFirstChild("LocalScript") then
            v:Destroy()
        end
    end
end
e(Plr.character)
local target
while wait() do
    target = nil
    local highest = 0
    for i, v in pairs(game.Players:GetPlayers()) do
        if v:FindFirstChild("DataFolder") and v.Character:FindFirstChild("FULLY_LOADED_CHAR") and v.Character.BodyEffects:FindFirstChild("Defense") and tonumber(v.DataFolder.Information.Wanted.Value) > 500 and tonumber(v.DataFolder.Information.Wanted.Value) >= highest and v.Character.BodyEffects:FindFirstChild("Armor") then
            target = v 
            highest = tonumber(v.DataFolder.Information.Wanted.Value)
        end
    end
    if not target then serverhop() end
    local e = true
    local penis = 0
    local bagged = false
    local A = false
    spawn(function() pcall(function()
        while bagged == false do
            if target and target.Character and target.Character:FindFirstChild("Christmas_Sock") == nil and penis <= 5 and Plr.Character.Humanoid.Health > 80 then
                if Plr.Backpack:FindFirstChild("[BrownBag]") == nil then
                    A = false
                    pcall(function()
                        repeat wait()
                            Plr.character.HumanoidRootPart.CFrame = CFrame.new(-316.034454, 48.2788467, -723.860474, 0.983254969, -0.000297372608, -0.182234928, 0.000218386791, 0.999999881, -0.000453495246, 0.182235047, 0.000406103791, 0.98325491)
                            fireclickdetector(game:GetService("Workspace").Ignored.Shop["[BrownBag] - $25"].ClickDetector)
                        until Plr.Backpack:FindFirstChild("[BrownBag]") ~= nil
                    end)
                    A = true
                end
                Plr.Character.Humanoid:EquipTool(Plr.Backpack["[BrownBag]"])
                Plr.Character["[BrownBag]"]:Activate()
                penis = penis + 1
            elseif penis >= 2 or target.Character:FindFirstChild("Christmas_Sock") or not target then
                bagged = true
            end
            wait(3)
        end
    end) end)
    spawn(function()
        while e do wait()
            pcall(function()
                if Plr.Character.Humanoid.Health > 80 then
                    if not target.Character.BodyEffects["K.O"].Value then
                        if A then
                            Plr.Character.HumanoidRootPart.CFrame = CFrame.new(target.Character.UpperTorso.Position + Vector3.new(0, -5, 0))
                        end
                    else
                        Plr.Character.HumanoidRootPart.CFrame = target.Character.UpperTorso.CFrame
                    end
                else
                    Plr.Character.HumanoidRootPart.CFrame = CFrame.new(0, 999, 0)
                    if Plr.Character:FindFirstChild("[Chicken]") == nil or Plr.Backpack:FindFirstChild("[Chicken]") == nil then
                        Plr.Character.HumanoidRootPart.CFrame = game.Workspace.Ignored.Shop["[Chicken] - $7"].Head.CFrame
                        wait(0.5)
                        fireclickdetector(game.Workspace.Ignored.Shop["[Chicken] - $7"].ClickDetector)
                    end
                    pcall(function()Plr.Character.Humanoid:EquipTool(Plr.Backpack["[Chicken]"])end)
                    pcall(function()
                        Plr.Character["[Chicken]"]:Activate()
                        wait(0.1)
                        Plr.Character["[Chicken]"]:Deactivate()
                    end)
                end
            end)
        end
    end)
    repeat wait() until bagged
    pcall(function()
        repeat wait()
            repeat wait()
                pcall(function()
                if Plr.Character.Humanoid.Health > 80 then
                    pcall(function()Plr.Character.Humanoid:EquipTool(Plr.Backpack["[Knife]"])end)
                    wait(0.1)
                        Plr.Character["[Knife]"].GripPos = Vector3.new(0, 5, 0)
                        Plr.Character["[Knife]"].Handle.Size = Vector3.new(20, 20, 20)
                        Plr.Character["[Knife]"]:Activate()
                        wait(2)
                        Plr.Character["[Knife]"]:Deactivate()
                        wait(1)
                    end
                end)
            until not target or target.Character.BodyEffects["K.O"].Value or game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.V)
            repeat wait() 
                if Plr.Character.Humanoid.Health > 80 then
                    pcall(function()Plr.Character.Humanoid:EquipTool(Plr.Backpack.Cuff)end)
                    pcall(function()
                        Plr.Character.Cuff:Activate()
                        wait(0.1)
                        Plr.Character.Cuff:Deactivate()
                    end)
                end
            until not target.Character.BodyEffects["K.O"].Value or game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.V)
        until tonumber(target.DataFolder.Information.Wanted.Value) == 0 or game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.V)
    end)
    e = false
end