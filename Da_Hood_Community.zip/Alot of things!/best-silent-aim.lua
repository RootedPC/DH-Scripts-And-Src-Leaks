-- functioning script below change "E" to any toggle key u want

local toggle = Enum.KeyCode.E

loadstring(game:HttpGet("https://raw.githubusercontent.com/urdad1234/BestSilentAim/main/Lua.source"))()
