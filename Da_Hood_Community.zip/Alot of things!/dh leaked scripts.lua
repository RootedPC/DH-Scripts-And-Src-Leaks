--hoodshrek
loadstring(game:HttpGet("https://pastebin.com/raw/nh1fsqbh", true))()
wait(5)
Da_Hood_Title.Text = ""
--sinister
loadstring(game:HttpGet("https://pastebin.com/raw/aHMue5sf", true))()