game.ReplicatedStorage.MainEvent:FireServer("PhoneCall", "preachdied")
while wait(38.388) do
    game.ReplicatedStorage.MainEvent:FireServer("PhoneCall", "preachdied")
end