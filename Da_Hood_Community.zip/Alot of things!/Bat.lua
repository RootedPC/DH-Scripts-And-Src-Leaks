-- made by Compwnter#5640
local b = 10 -- how many bats u want
----------------------------------------------------------------------------------------------
local a = {}
repeat
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Workspace.Ignored.Shop["[Bat] - $250"].Head.CFrame + Vector3.new(0, 3, 0)
    wait(0.6)
    fireclickdetector(game:GetService("Workspace").Ignored.Shop["[Bat] - $250"].ClickDetector)
    for i, v in pairs(game.Players.LocalPlayer.Backpack:GetChildren()) do
        if v.Name == "[Bat]" then
            v.Parent = game.Players.LocalPlayer.Character
            table.insert(a, v)
        end
    end
until #a >= b
local c = -2
for i, v in next, game.Players.LocalPlayer.Character:GetChildren() do
    if v.Name == "[Bat]" then
        v.Parent = game.Players.LocalPlayer.Backpack
        v.GripPos = Vector3.new(0, c, 0)
        c = c + - 2
        v.GripForward = Vector3.new(0, 0, 0)
        v.GripRight = Vector3.new(0, 0, 0)
        v.GripUp = Vector3.new(0, 100, 0)
        v.Parent = game.Players.LocalPlayer.Character
    end
end