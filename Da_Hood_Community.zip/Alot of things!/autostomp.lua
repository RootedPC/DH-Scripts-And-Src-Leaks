lp = game:GetService("Players").LocalPlayer
             rs = game:GetService("RunService")
        --//------------------------------------------------------------------------------------------\\--
            assert(getrawmetatable)
            gmt = getrawmetatable(game)
            setreadonly(gmt, false)
            old = gmt.__namecall
            gmt.__namecall =
                newcclosure(
                    function(self, ...)
                    local args = {...}
                    if tostring(args[1]) == "TeleportDetect" then
                        return
                    elseif tostring(args[1]) == "CHECKER_1" then
                        return
                    elseif tostring(args[1]) == "CHECKER" then
                        return end
                    return old(self, ...)
                    end)
        --//------------------------------------------------------------------------------------------\\--
            lp.Chatted:Connect(function(msg)
                if msg == "AutoStomp!" then
                        game.StarterGui:SetCore(
                "SendNotification",
                {
                    Title = "Auto-Stomp On",
                    Text = "Enabled",
                }
                )
                rs:BindToRenderStep("STOMPING", 200 , function()
                pcall(function()
                    for i,v in pairs(game:GetService("Players"):GetPlayers()) do
                     if v.Character and v.Character:FindFirstChild("BodyEffects") and v.Character.BodyEffects:FindFirstChild("K.O") and v.Character.BodyEffects:FindFirstChild("Dead") and v.Character.BodyEffects["K.O"].Value == true and v.Character.BodyEffects.Dead.Value == false and v.Name ~= lp.Name and v.Character:FindFirstChild("UpperTorso") then
                        lp.Character.HumanoidRootPart.CFrame = v.Character.UpperTorso.CFrame
                         game:GetService('ReplicatedStorage'):FindFirstChild('MainEvent'):FireServer('Stomp')
                    else end
                    end
                end)
            end)
            elseif msg == "Disable!" then
                game.StarterGui:SetCore(
                "SendNotification",
                {
                    Title = "Auto-Stomp Off",
                    Text = "Disabled",
                }
                )
                rs:UnbindFromRenderStep("STOMPING")
            end
        end)
    print"loaded"