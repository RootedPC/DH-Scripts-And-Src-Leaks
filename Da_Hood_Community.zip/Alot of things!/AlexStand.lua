getgenv().Settings =  {
    ['Owner'] = 'fadyazzi009';
};

getgenv().Commands =  {
    ['Summon'] = 'Summon';
    ['Multi'] = 'Protect';
    ['Grow'] = 'Grow';
    ['Aura'] = 'Protect me';
    ['Vanish'] = 'Hide';
    ['Mimic'] = 'Copy';
    ['Barrage'] = 'Kill';
    ['Stab'] = 'Charge';
    ['Banish'] = 'Fling';
    ['Reset'] = 'Reset';
};

loadstring(game:HttpGet('https://raw.githubusercontent.com/SwagStando/SwagStando/main/SwagStando'))();